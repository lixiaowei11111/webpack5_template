webpack
webpack-cli
dotenv
cross-env
xxx-laoder ...
react ...
ts ...
@types/node....
babel ....
postcss ....
scss/less
tailwindcss

eslint
stylelint
husky
commitlint
prettier
editorConfig


TypeScript 相比于 Babel 的优点在于它原生支持 JSX 语法，你不需要重新安装新的依赖，只需修改一行配置。 但 TypeScript 的不同在于：

使用了 JSX 语法的文件后缀必须是 tsx。
由于 React 不是采用 TypeScript 编写的，需要安装 react 和 react-dom 对应的 TypeScript 接口描述模块 @types/react 和 @types/react-dom 后才能通过编译。
