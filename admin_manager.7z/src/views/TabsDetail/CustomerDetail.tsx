import React from 'react'

const CustomerDetail: React.FC = () => {
	return (
		<>
			<div>CustomerDetail</div>
		</>
	)
}

export default CustomerDetail
