import React from 'react'

const LeadsDetail: React.FC = () => {
	return (
		<>
			<div>LeadsDetail</div>
		</>
	)
}

export default LeadsDetail
